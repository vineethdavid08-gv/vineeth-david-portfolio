# Vineeth David — Creative Portfolio

This folder is ready for GitHub Pages.

## Publish
1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then **Save**.
6. Your site will be available at:
   `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`

The portfolio uses Instagram's official embed script, so the Reel previews depend on Instagram allowing the embeds to load.
